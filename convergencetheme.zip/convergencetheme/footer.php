      <!-- <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script> -->
      <!-- <script src="https://convergence.rmc.edu/wp-content/themes/convergence/assets/js/main.js"></script>-->
      <script src="wp-content/themes/convergencetheme/assets/js/main.js"></script>
      <script src="https://kit.fontawesome.com/69bb1b6c47.js" crossorigin="anonymous"></script>
      <script type='text/javascript'>
        /* 
								<![CDATA[ */
        var wpcf7 = {
          "apiSettings": {
            "root": "https:\/\/convergence.rmc.edu\/wp-json\/contact-form-7\/v1",
            "namespace": "contact-form-7\/v1"
          }
        };
        /* ]]> */
      </script>
      <!-- <script type='text/javascript' src='https://convergence.rmc.edu/wp-content/plugins/contact-form-7/includes/js/scripts.js'></script>-->
      <!-- <script type='text/javascript' src='https://convergence.rmc.edu/wp-includes/js/wp-embed.min.js'></script>-->
  </body>
</html>